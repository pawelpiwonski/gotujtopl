<?php 
  define('DB_HOST', 'localhost');
  define('DB_USER', 'pawelhmc');
  define('DB_PASS', 'Hmcn0_va');
  define('DB_NAME', 'pawelhmc_gotujto');

  define('APPROOT', dirname(__FILE__, 2));
  define('URLROOT', 'https://gotujto.pl');
