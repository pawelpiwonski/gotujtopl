<?php 
  define('DB_HOST', 'localhost');
  define('DB_USER', 'pawelhmc');
  define('DB_PASS', 'Hmcn0_va');
  define('DB_NAME', 'pawelhmc_testgotujto');

  define('APPROOT', dirname(__FILE__, 2));
  define('URLROOT', 'https://pawel.hmcloud.pl/gotujtopl_test');