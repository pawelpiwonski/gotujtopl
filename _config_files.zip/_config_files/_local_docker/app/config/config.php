<?php 
  define('DB_HOST', 'h2.hitme.pl');
  define('DB_USER', 'pawelhmc');
  define('DB_PASS', 'Hmcn0_va');
  define('DB_NAME', 'pawelhmc_testgotujto');

  define('APPROOT', dirname(__FILE__, 2));
  define('URLROOT', 'http://localhost');
